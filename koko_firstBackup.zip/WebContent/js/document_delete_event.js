function delete_event(){
	if(confirm('정말 삭제하시겠습니까?') == true) { //삭제
		document.form.submit();
	} else { //취소
		return;
	}
}